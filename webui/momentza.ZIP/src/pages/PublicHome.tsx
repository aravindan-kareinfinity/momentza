
import React, { useState, useEffect } from 'react';
import { TopNavigation } from '@/components/Layout/TopNavigation';
import { PublicHomeCarousel } from '@/components/Home/PublicHomeCarousel';
import { PublicHallsSection } from '@/components/Home/PublicHallsSection';
import { CustomerClicksSection } from '@/components/Home/CustomerClicksSection';
import { PublicReviewsSection } from '@/components/Home/PublicReviewsSection';
import { PublicFooter } from '@/components/Home/PublicFooter';
import { ServerErrorDialog } from '@/components/ui/ServerErrorDialog';
import { 
  organizationService, 
  hallService, 
  carouselService, 
  galleryService, 
  customerClicksService, 
  reviewService 
} from '@/services/ServiceFactory';

// Page-level context data
interface PublicHomeData {
  organization: any;
  halls: any[];
  carouselItems: any[];
  galleryImages: any[];
  customerClicks: any[];
  reviews: any[];
}

const PublicHome = () => {
  // Page-level state for all data
  const [pageData, setPageData] = useState<PublicHomeData>({
    organization: null,
    halls: [],
    carouselItems: [],
    galleryImages: [],
    customerClicks: [],
    reviews: []
  });
  
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);
  const [showErrorDialog, setShowErrorDialog] = useState(false);

  // Fetch all data once when page initializes
  const fetchPageData = async () => {
    try {
      setLoading(true);
      setError(null);
      console.log('[PublicHome] Fetching all page data...');

      // Fetch organization first (needed for other calls)
      const organization = await organizationService.getCurrentOrganization();
      
      if (!organization?.id) {
        throw new Error('Organization not found');
      }

      // Fetch all data in parallel
      const [
        halls,
        carouselItems,
        galleryImages,
        customerClicks,
        reviews
      ] = await Promise.all([
        hallService.getAllHalls(),
        carouselService.getCarouselItems(organization.id),
        galleryService.getImagesByOrganization(organization.id),
        customerClicksService.getAll(),
        reviewService.getReviewsByOrganization(organization.id)
      ]);

      setPageData({
        organization,
        halls,
        carouselItems,
        galleryImages,
        customerClicks,
        reviews
      });

      setShowErrorDialog(false);
    } catch (err) {
      const error = err as Error;
      console.error('[PublicHome] Error fetching page data:', error);
      setError(error);
      setShowErrorDialog(true);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPageData();
  }, []); // Only run once when page mounts

  const handleRetry = async () => {
    await fetchPageData();
  };

  const handleCloseErrorDialog = () => {
    setShowErrorDialog(false);
  };

  // Loading state
  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <TopNavigation organization={null} />
        <main>
          <div className="animate-pulse">
            <div className="h-96 md:h-[500px] lg:h-[600px] bg-gray-200 rounded mb-12"></div>
            <div className="container mx-auto px-4">
              <div className="h-8 bg-gray-200 rounded w-1/4 mb-8"></div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="h-64 bg-gray-200 rounded"></div>
                ))}
              </div>
            </div>
          </div>
        </main>
        <div className="h-32 bg-gray-900"></div>
      </div>
    );
  }

  // Error state
  if (error || !pageData.organization) {
    return (
      <div className="min-h-screen bg-background">
        <TopNavigation organization={null} />
        <main>
          <div className="container mx-auto px-4 py-12">
            <div className="text-center">
              <p>Unable to load page data</p>
            </div>
          </div>
        </main>
        <div className="h-32 bg-gray-900"></div>
        
        <ServerErrorDialog
          isOpen={showErrorDialog}
          onClose={handleCloseErrorDialog}
          onRetry={handleRetry}
          isLoading={loading}
          title="Page Data Error"
          message={error?.message || 'Unable to load page data. Please try again.'}
        />
      </div>
    );
  }

  return (
    <>
      <div className="min-h-screen bg-background">
        <TopNavigation organization={pageData.organization} />
        <main>
          <PublicHomeCarousel 
            organization={pageData.organization}
            carouselItems={pageData.carouselItems}
            galleryImages={pageData.galleryImages}
          />
          <PublicHallsSection 
            halls={pageData.halls}
          />
          <CustomerClicksSection 
            customerClicks={pageData.customerClicks}
          />
          <PublicReviewsSection 
            organization={pageData.organization}
          />
        </main>
        <PublicFooter 
          organization={pageData.organization}
        />
      </div>

      <ServerErrorDialog
        isOpen={showErrorDialog}
        onClose={handleCloseErrorDialog}
        onRetry={handleRetry}
        isLoading={loading}
        title="Page Data Error"
        message={error?.message || 'Unable to load page data. Please try again.'}
      />
    </>
  );
};

export default PublicHome;
