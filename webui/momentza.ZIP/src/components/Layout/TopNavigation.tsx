import React from 'react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { Organization } from '@/types';
import { LogIn } from 'lucide-react';

interface TopNavigationProps {
  organization: Organization;
}

export function TopNavigation({ organization }: TopNavigationProps) {
  const navigate = useNavigate();

  const handleLogin = () => {
    navigate('/login');
  };

  if (!organization) {
    return (
      <nav className="bg-white shadow-sm border-b">
        <div className="flex justify-between items-center h-16 pl-2 pr-2">
          <div className="flex items-center">
            <h1 className="text-xl font-bold text-gray-900">Organization</h1>
          </div>
          <div className="flex justify-end">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={handleLogin}
              className="flex items-center gap-2"
            >
              <LogIn className="h-4 w-4" />
              Login
            </Button>
          </div>
        </div>
      </nav>
    );
  }

  return (
    <nav className="bg-white shadow-sm border-b">
      <div className="flex justify-between items-center h-16 pl-2 pr-2">
        <div className="flex items-center">
          <img
            src={organization?.logo}
            alt={organization?.name}
            className="h-8 w-8 mr-3 ml-0"
          />
          <h1 className="text-xl font-bold text-gray-900">{organization?.name}</h1>
        </div>
        <div className="flex justify-end">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={handleLogin}
            className="flex items-center gap-2"
          >
            <LogIn className="h-4 w-4" />
            Login
          </Button>
        </div>
      </div>
    </nav>
  );
}
