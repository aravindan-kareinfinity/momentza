import { IOrganizationService } from '../interfaces/IDataService';
import { Organization } from '../../types';
import { apiClient } from '../http/ApiClient';

export class ApiOrganizationService implements IOrganizationService {
  private static instance: ApiOrganizationService;
  private cachedOrganization: Organization | null = null;
  private isLoading = false;
  private error: Error | null = null;
  private lastFetchTime: number = 0;
  private readonly CACHE_DURATION = 5 * 60 * 1000; // 5 minutes cache

  private constructor() {}

  public static getInstance(): ApiOrganizationService {
    if (!ApiOrganizationService.instance) {
      ApiOrganizationService.instance = new ApiOrganizationService();
    }
    return ApiOrganizationService.instance;
  }

  private isCacheValid(): boolean {
    return this.cachedOrganization !== null && 
           (Date.now() - this.lastFetchTime) < this.CACHE_DURATION;
  }

  private clearCache(): void {
    this.cachedOrganization = null;
    this.error = null;
    this.lastFetchTime = 0;
  }

  async getCurrentOrganization(): Promise<Organization> {
    // Return cached data if valid
    if (this.isCacheValid()) {
      console.log('🔍 ApiOrganizationService: Returning cached organization:', this.cachedOrganization);
      return Promise.resolve(this.cachedOrganization!);
    }

    // If already loading, wait for the current request
    if (this.isLoading) {
      console.log('🔍 ApiOrganizationService: Request already in progress, waiting...');
      return new Promise((resolve, reject) => {
        const checkCache = () => {
          if (this.error) {
            reject(this.error);
          } else if (this.cachedOrganization) {
            resolve(this.cachedOrganization);
          } else {
            setTimeout(checkCache, 100);
          }
        };
        checkCache();
      });
    }

    // Start new request
    this.isLoading = true;
    this.error = null;

    try {
      console.log('🔍 ApiOrganizationService: Fetching organization data from API...');
      
      const organization = await apiClient.get<Organization>('/api/organizations/current');
      
      // Cache the successful result
      this.cachedOrganization = organization;
      this.lastFetchTime = Date.now();
      this.isLoading = false;
      
      console.log('🔍 ApiOrganizationService: Successfully cached organization:', organization);
      return organization;
    } catch (error) {
      this.error = error as Error;
      this.isLoading = false;
      console.error('🔍 ApiOrganizationService: Error fetching organization:', error);
      throw error;
    }
  }

  // Method to force refresh the cache
  async refreshOrganization(): Promise<Organization> {
    this.clearCache();
    return this.getCurrentOrganization();
  }

  // Method to get cached organization without making API call
  getCachedOrganization(): Organization | null {
    return this.isCacheValid() ? this.cachedOrganization : null;
  }

  // Method to check if there's a cached error
  getLastError(): Error | null {
    return this.error;
  }

  // Method to clear error state
  clearError(): void {
    this.error = null;
  }

  async getAll(): Promise<Organization[]> {
    return apiClient.get<Organization[]>('/api/organizations');
  }

  async getById(id: string): Promise<Organization | null> {
    try {
      return await apiClient.get<Organization>(`/api/organizations/${id}`);
    } catch (error) {
      if (error.status === 404) {
        return null;
      }
      throw error;
    }
  }

  async create(data: Omit<Organization, 'id'>): Promise<Organization> {
    return apiClient.post<Organization>('/api/organizations', data);
  }

  async update(id: string, data: Partial<Organization>): Promise<Organization> {
    const updatedOrg = await apiClient.put<Organization>(`/api/organizations/${id}`, data);
    
    // Update cache if this is the current organization
    if (this.cachedOrganization && this.cachedOrganization.id === id) {
      this.cachedOrganization = { ...this.cachedOrganization, ...data };
    }
    
    return updatedOrg;
  }

  async delete(id: string): Promise<boolean> {
    try {
      await apiClient.delete(`/api/organizations/${id}`);
      return true;
    } catch (error) {
      return false;
    }
  }

  async updateOrganization(id: string, data: Partial<Organization>): Promise<Organization> {
    return this.update(id, data);
  }
} 